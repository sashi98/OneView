package gui.bean;

import gui.util.StringUtil;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static gui.ui.constants.GuiConstants.GLOBAL_ERROR_MSG;
import static gui.ui.constants.GuiConstants.SIMPLE_DATE_FORMAT;

public class ServerContext implements OneViewContext{

    private HashMap<String, Object> hm;

    public ServerContext(){
        hm = new HashMap<>();
    }

    public void set(String key, Object val){
        hm.put(key,val);
    }

    public void validate() {}

    public String getStringValue(String key) {
        String val = String.valueOf(hm.get(key));
        return (val == null || val.equals("null") || val.trim().equals(""))?"":val;
    }

    public List getListValue(String key){
        return (List) hm.get(key);
    }

}
