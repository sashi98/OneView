package gui.bean;

import java.io.Serializable;

public interface OneViewContext extends Serializable {
    public String getStringValue(String key);
}
