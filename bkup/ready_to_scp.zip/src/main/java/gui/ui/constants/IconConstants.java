package gui.ui.constants;

import gui.ui.icon.ImagePanel;
import gui.util.FileUtil;

import javax.swing.*;
import java.awt.*;

import static gui.ui.constants.DimensionConstants.ICON_HEIGHT;
import static gui.ui.constants.DimensionConstants.ICON_WIDTH;
import static java.awt.Image.SCALE_SMOOTH;
import static java.lang.Boolean.TRUE;

public class IconConstants {
    public static final boolean FALSE = false;
    public static String SLASH = "/";
    public static String ICON_DIR= SLASH+"icons"+ SLASH +"in_use";
    public static String ICON_GIF_DIR= ICON_DIR+ SLASH +"gifs";

    public static final ImagePanel BUSY_SPIN_IP = new ImagePanel(ICON_GIF_DIR+ SLASH +"busy_spin.gif");

    public static final ImagePanel RESTART_IP = new ImagePanel(ICON_DIR+ SLASH +"restart.png");
    public static final ImagePanel RESTARTING_IP = new ImagePanel(ICON_GIF_DIR+ SLASH +"restarting.gif");
    public static final ImagePanel RESTARTED_IP = new ImagePanel(ICON_DIR+ SLASH +"restarted.png");
    
    public static final ImagePanel STARTED_IP = new ImagePanel(ICON_DIR+ SLASH +"started1.png"/*, (ICON_WIDTH/2)+4, (ICON_HEIGHT/2)+4,true, Color.WHITE*/);
    public static final ImagePanel STOPPED_IP = new ImagePanel(ICON_DIR+ SLASH +"stopped1.png"/*, (ICON_WIDTH/2)+4, (ICON_HEIGHT/2)+4,true, Color.WHITE*/);

    public static final ImagePanel INFO_IP = new ImagePanel(ICON_DIR+ SLASH +"info.png", "Click here");
    public static final ImagePanel OK_IP = new ImagePanel(ICON_DIR+ SLASH +"ok.png");
    public static final ImagePanel NOT_OK_IP = new ImagePanel(ICON_DIR+ SLASH +"not_ok.png"/*, ICON_WIDTH, ICON_HEIGHT, FALSE, Color.WHITE*/);


    public static final ImageIcon TRIGGERED_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"trigger.png");
    public static final ImageIcon TRIGGERED_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"trigger1.png");

    public static final ImageIcon FOLDER_OPEN_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"open.png");
    public static final ImageIcon FOLDER_OPEN_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"open1.png");

    public static final ImageIcon ADD_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"add.png");
    public static final ImageIcon ADD_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"add1.png");

    public static final ImageIcon REMOVE_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"remove.png");
    public static final ImageIcon REMOVE_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"remove1.png");

    public static final ImageIcon TRASH_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"trash.png");
    public static final ImageIcon TRASH_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"trash1.png");

    public static final ImageIcon DESC_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"desc.png");
    public static final ImageIcon ASC_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"asc.png");

    public static final ImageIcon ARROW_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"arrow.png");
    public static final ImageIcon ARROW_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"arrow1.png");

    public static final ImageIcon CALLENDER_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"calendar.png");
    public static final ImageIcon CALLENDER_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"calendar1.png");

    public static final ImageIcon CALLENDER_DEFAULT_SICON = FileUtil.getScaledIcon(CALLENDER_DEFAULT_ICON, ICON_WIDTH, ICON_HEIGHT, SCALE_SMOOTH);
    public static final ImageIcon CALLENDER_HOVERED_SICON = FileUtil.getScaledIcon(CALLENDER_HOVERED_ICON, ICON_WIDTH, ICON_HEIGHT, SCALE_SMOOTH);

    public static final ImageIcon ON_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"on.png");
    public static final ImageIcon OFF_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"off.png");

    public static final ImageIcon ADD_TAB_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"add_tab.png");
    public static final ImageIcon ADD_TAB_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"add_tab1.png");

    public static final ImageIcon CLOSE_TAB_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"close_tab.png");
    public static final ImageIcon CLOSE_TAB_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"close_tab1.png");

    public static final ImageIcon APPLY_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"apply.png");
    public static final ImageIcon CANCEL_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"cancel.png");

    public static final ImageIcon VIEW_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"view.png");
    public static final ImageIcon VIEW_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"view1.png");

    //public static final ImageIcon EDIT_DEFAULT_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"edit.png");
    //public static final ImageIcon EDIT_HOVERED_ICON = FileUtil.getIcon(ICON_DIR+ SLASH +"edit1.png");

}
