package gui.ui.triggerbutton;

import gui.bean.ESContext;
import gui.ui.component.CJButton;
import gui.ui.component.CJPanel;
import gui.util.FileUtil;

import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;

import static gui.bean.ESContext.*;
import static gui.ui.constants.IconConstants.*;
import static gui.ui.constants.DimensionConstants.ICON_HEIGHT;
import static gui.ui.constants.DimensionConstants.ICON_WIDTH;

/**
 * This class is not being used any more .. safe to delete
 *
 */
public class TriggerButtonUI extends CJPanel {
    CJButton triggerButton;


    public TriggerButtonUI() {
        super();
        triggerButton = new CJButton(TRIGGERED_DEFAULT_ICON, TRIGGERED_HOVERED_ICON, ICON_WIDTH, ICON_HEIGHT, "Trigger Job");
        this.setLayout(new GridLayout(1,1,0,0));
        this.add(triggerButton);
        this.setBorder(new LineBorder(Color.LIGHT_GRAY));
    }

    public CJButton getTriggerButton() {
        return triggerButton;
    }

    /*public void actionPerformed(ActionEvent e, ESContext esContext) {
        try {
            String date = esContext.getStringValue(START_DATE_TIME).replaceAll("\\p{Punct}","")
                    .replaceAll("\\p{Blank}", "_");
            esContext.set(TRIGGER_FILE_NAME, esContext.getStringValue(CRON_JOB_NAME)+"-"+date+".xml");
            FileUtil.onDemandTriggering(esContext);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }*/
}
