package gui.ui.tables.server;

import gui.TableData;

import static gui.ui.constants.GuiConstants.*;


public class ServerTableData implements TableData {
    private String serverName;
    private String home;
    private String startTime;
    private String startStop;
    private String restart;

    public ServerTableData() {
        this.startStop = STOPPED;
        this.restart = RESTART;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getHome() {
        return home;
    }

    public void setHome(String home) {
        this.home = home;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }


    public String getStartStop() {
        return startStop;
    }

    public void setStartStop(String startStop) {
        this.startStop = startStop;
    }

    public String getRestart() {
        return restart;
    }

    public void setRestart(String restart) {
        this.restart = restart;
    }

}
