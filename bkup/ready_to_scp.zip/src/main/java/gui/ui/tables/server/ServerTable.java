package gui.ui.tables.server;

import gui.bean.OneViewContext;
import gui.bean.ServerContext;
import gui.ui.RegisterListener;
import gui.ui.component.CJTable;
import gui.ui.tables.renderer.*;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;

import static gui.ui.constants.GuiConstants.*;
import static gui.ui.screens.ServersScreen.SERVER_HOME;
import static gui.ui.screens.ServersScreen.SERVER_NAME;
import static gui.util.DateUtil.sleep;

public class ServerTable extends CJTable implements RegisterListener {
    private ServerTableDataModel serverTableDataModel;
    private StartStopCellRenderer startStopCellRenderer;
    private RestartCellRenderer restartCellRenderer;
    private SortingColumnHeaderRenderer sortingColumnHeaderRenderer;
    private ColumnHeaderRenderer columnHeaderRenderer;
    private int defaultSortingColumn = 1;
    private boolean DESC = true;

    public ServerTable(ServerTableDataModel dataModel) {
        super(dataModel);
        this.serverTableDataModel = dataModel;
        this.sortingColumnHeaderRenderer = new SortingColumnHeaderRenderer(DESC);
        this.columnHeaderRenderer = new ColumnHeaderRenderer();
        this.startStopCellRenderer = new StartStopCellRenderer();
        this.restartCellRenderer = new RestartCellRenderer();
        getTableHeader().setPreferredSize(new Dimension(100, 25));
        setRowSelectionAllowed(false);
        setSelectionBackground(Color.white);
        setCellRenderer();
        setHeaderRenderer();
        registerListener();
        setRowHeight(30);
    }

    private ServerTable getInvoker() {
        return this;
    }

    private void setCellRenderer() {
        NormalCellRenderer defaultTableCellRenderer = new NormalCellRenderer();
        defaultTableCellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        defaultTableCellRenderer.setBorder(new LineBorder(Color.BLACK));

        getColumnModel().getColumn(ServerTableDataModel.ColumnIndex.SERVER_NAME_INDEX.ordinal()).setCellRenderer(defaultTableCellRenderer);
        getColumnModel().getColumn(ServerTableDataModel.ColumnIndex.HOME_PATH_INDEX.ordinal()).setCellRenderer(defaultTableCellRenderer);
        getColumnModel().getColumn(ServerTableDataModel.ColumnIndex.START_TIME_INDEX.ordinal()).setCellRenderer(defaultTableCellRenderer);
        getColumnModel().getColumn(ServerTableDataModel.ColumnIndex.START_STOP_INDEX.ordinal()).setCellRenderer(startStopCellRenderer);
        getColumnModel().getColumn(ServerTableDataModel.ColumnIndex.RESTART_INDEX.ordinal()).setCellRenderer(restartCellRenderer);

    }

    private void setHeaderRenderer() {
        Enumeration<TableColumn> tableColumns = this.getTableHeader().getColumnModel().getColumns();
        while (tableColumns.hasMoreElements()) {
            TableColumn tc = tableColumns.nextElement();
            if (tc.getModelIndex() == getDefaultSortingColumn()) {
                tc.setHeaderRenderer(sortingColumnHeaderRenderer);
            } else {
                tc.setHeaderRenderer(columnHeaderRenderer);
            }
        }
    }

    public ServerTableDataModel getServerTableDataModel() {
        return serverTableDataModel;
    }

    @Override
    public void updateTable(OneViewContext context) {
        if (context instanceof ServerContext) {
            ServerContext serverContext = (ServerContext) context;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String serverName = serverContext.getStringValue(SERVER_NAME);
                    String serverHome = serverContext.getStringValue(SERVER_HOME);
                    ServerTableData data = new ServerTableData();
                    data.setServerName(serverName);
                    data.setHome(serverHome);
                    data.setStartStop(STOPPED);
                    data.setRestart(RESTART);
                    serverTableDataModel.getDataList().add(data);
                    serverTableDataModel.fireTableDataChanged();
                }
            }).start();
            repaint();
        }
    }


    private void sort() {

    }

    public int getDefaultSortingColumn() {
        return defaultSortingColumn;
    }

    public void setDefaultSortingColumn(int defaultSortingColumn) {
        this.defaultSortingColumn = defaultSortingColumn;
    }

    public void clearTable() {
        serverTableDataModel.getDataList().removeAll(serverTableDataModel.getDataList());
        serverTableDataModel.fireTableDataChanged();
    }

    public void sortingPerformed(MouseEvent e) {
        DESC = !DESC;
        sortingColumnHeaderRenderer.setDesc(DESC);
        TableColumnModel colModel = ((JTableHeader) e.getSource()).getColumnModel();
        int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
        setDefaultSortingColumn(columnModelIndex);
        setHeaderRenderer();
        sort();
    }

    @Override
    public void registerListener() {
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Point clickPoint = e.getPoint();
                int row = rowAtPoint(clickPoint);
                int col = columnAtPoint(clickPoint);
                Rectangle cellRect = getCellRect(row, col, true);
                if (col == ServerTableDataModel.ColumnIndex.START_STOP_INDEX.ordinal()){
                    StartStopCellRenderer cellRenderer = (StartStopCellRenderer) getColumnModel().getColumn(ServerTableDataModel.ColumnIndex.START_STOP_INDEX.ordinal()).getCellRenderer();
                    JComponent ip = cellRenderer.getComponent();
                    Rectangle ipRect = ip.getBounds();
                    Rectangle ipBounds = new Rectangle(cellRect.x + ipRect.x, cellRect.y + ipRect.y, ipRect.width, ipRect.height);
                    if (ipBounds.contains(clickPoint)) {
                        ServerTableData data = serverTableDataModel.getDataList().get(row);
                        data.setStartStop(BUSY_SPIN);
                        serverTableDataModel.fireTableDataChanged();
                        new Thread(() -> {
                            int k=0;
                            while (k <= 20) {
                                sleep(100);
                                k++;
                                repaint();
                            }
                            data.setStartStop(STARTED);
                            serverTableDataModel.fireTableDataChanged();
                        }).start();

                    }
                }
                if (col == ServerTableDataModel.ColumnIndex.RESTART_INDEX.ordinal()) {
                    RestartCellRenderer cellRenderer = (RestartCellRenderer) getColumnModel().getColumn(ServerTableDataModel.ColumnIndex.RESTART_INDEX.ordinal()).getCellRenderer();
                    JComponent ip = cellRenderer.getComponent();
                    Rectangle ipRect = ip.getBounds();
                    Rectangle ipBounds = new Rectangle(cellRect.x + ipRect.x, cellRect.y + ipRect.y, ipRect.width, ipRect.height);
                    if (ipBounds.contains(clickPoint)) {
                        ServerTableData data = serverTableDataModel.getDataList().get(row);
                        data.setRestart(RESTARTING);
                        serverTableDataModel.fireTableDataChanged();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                int k=0;
                                while (k <= 20) {
                                    sleep(100);
                                    k++;
                                    repaint();
                                }
                                data.setRestart(RESTARTED);

                            }
                        }).start();

                    }
                }
                repaint();
            }

        });

        getTableHeader().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                sortingPerformed(e);
            }
        });
    }
}
