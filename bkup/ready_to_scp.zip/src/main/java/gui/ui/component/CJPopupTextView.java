package gui.ui.component;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Map;

import static gui.ui.constants.GuiConstants.LINE_GRAY_1THK_BORDER;
import static gui.ui.constants.GuiConstants.NORMAL_TXT_FONT;
import static gui.util.GuiUtil.newDimentionObj;

public class CJPopupTextView extends JPopupMenu {
    private JTextPane textPane;
    private JScrollPane scrollPane;
    private int x;
    private int y;
    private Component invoker;
    public CJPopupTextView(String txt, int x, int y, Component invoker, int w, int h){
        this.textPane = new JTextPane();
        this.x= x;
        this.y =y;
        this.invoker=invoker;
        this.textPane.setText(txt);
        this.setFont(NORMAL_TXT_FONT);
        this.scrollPane = new JScrollPane(textPane);
        this.scrollPane.setPreferredSize(newDimentionObj(w, h));
        this.setBorder(LINE_GRAY_1THK_BORDER);
        this.add(scrollPane);
        this.setPreferredSize(newDimentionObj(w,h));
    }

    public CJPopupTextView(Map<String, String> map, int x, int y, ActionListener actionListener, int w, int h) {
        this.textPane = new JTextPane();
        this.x= x;
        this.y =y;
        this.invoker=invoker;
        //this.textPane.setText( );
        this.setFont(NORMAL_TXT_FONT);
        this.scrollPane = new JScrollPane(textPane);
        this.scrollPane.setPreferredSize(newDimentionObj(w, h));
        this.setBorder(LINE_GRAY_1THK_BORDER);
        this.add(scrollPane);
        this.setPreferredSize(newDimentionObj(w,h));
    }

    public void showIt(){
        this.show(invoker, x, y);
    }
}
