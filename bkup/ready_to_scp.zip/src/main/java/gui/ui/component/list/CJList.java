package gui.ui.component.list;

import gui.ui.component.CJLabel;
import gui.ui.component.CJPanel;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

import static gui.ui.constants.GuiConstants.*;

public class CJList extends JList {

    public CJList(DefaultListModel<String> listModel) {
        super(listModel);
        this.setCellRenderer((list, value, index, isSelected, cellHasFocus) -> {
            CJPanel panel = new CJPanel(true, Color.RED, Color.RED);
            CJLabel label = new CJLabel(String.valueOf(value));
            label.setFont(TITLE_HEADER_3_FONT);
            panel.setBorder(new LineBorder(Color.gray));
            if (isSelected){
                panel.setBorder(new LineBorder(Color.black));
                panel.setColor1(Color.WHITE);
                panel.setColor2(Color.RED);
                label.setForeground(Color.BLACK);
            }
            panel.add(label);
            return panel;
        });
    }
}
