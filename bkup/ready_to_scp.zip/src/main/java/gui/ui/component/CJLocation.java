package gui.ui.component;

import gui.ui.RegisterListener;
import gui.util.StringUtil;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import static gui.ui.constants.GuiConstants.*;
import static gui.ui.constants.IconConstants.*;
import static gui.ui.constants.DimensionConstants.*;
import static gui.util.GuiUtil.newGBC;

public class CJLocation extends CJPanel implements RegisterListener {
    private CJTextField locationTF;
    private CJButton openButton;
    private CJPanel parent;

    public CJLocation(String name, int width) {

        openButton = new CJButton(FOLDER_OPEN_DEFAULT_ICON, FOLDER_OPEN_HOVERED_ICON, ICON_WIDTH, ICON_HEIGHT, "Folder Open");
        locationTF = new CJTextField(width, TEXT_FIELD_HEIGHT);
        createUI();
        if (name !=null) {
            this.setBorder(new TitledBorder(LINE_LGRAY_1THK_BORDER, name, TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, TITLE_HEADER_2_FONT));
        }
        registerListener();
    }

    public CJLocation(CJPanel parent, String name, int width) {
        this(name,width);
        this.parent = parent;
    }

    private void createUI() {
       // gridBagLayout();
        flowLayout();
    }

    private void gridBagLayout() {
        LayoutManager lm = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        this.setLayout(lm);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        this.add(locationTF,c);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 0;
        this.add(openButton,c);
    }

    private void flowLayout() {
        this.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
        this.add(locationTF);
        this.add(openButton);
    }


    public JTextField getLocationTF() {
        return locationTF;
    }

    public CJButton getOpenButton() {
        return openButton;
    }

    @Override
    public void registerListener() {
        final CJLocation CJLocation = this;
        final String PWD = ".";
        this.openButton.addActionListener(actionEvent -> {
            JFileChooser fileChooser = new JFileChooser();
            File currentDir = new File(StringUtil.isBlank(locationTF.getText()) ? PWD : locationTF.getText());
            fileChooser.setCurrentDirectory(currentDir);
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int option = fileChooser.showOpenDialog(CJLocation);
            if (option == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try {
                    locationTF.setText(file.getCanonicalPath());
                } catch (IOException ex) {
                    JOptionPane.showConfirmDialog(CJLocation, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
            parent.fireContextListener();
        });
    }
}
