package gui.ui.component;

import gui.bean.OneViewContext;
import gui.ui.constants.GuiConstants;
import gui.ui.tables.triggerlog.TriggerLogTableDataModel;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;

import java.awt.*;

import static gui.ui.constants.DimensionConstants.TABLE_ROW_HEIGHT;

public abstract class CJTable extends JTable {
    private TriggerLogTableDataModel tm;
    public CJTable(AbstractTableModel tm){
        super(tm);
        this.setRowHeight(TABLE_ROW_HEIGHT);
        this.setBorder(GuiConstants.LINE_GRAY_1THK_BORDER);
        this.setBackground(Color.getColor("#ADD8E6"));

    }

    public abstract void updateTable(OneViewContext ctx);
}
