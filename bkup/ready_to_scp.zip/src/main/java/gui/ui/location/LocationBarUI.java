package gui.ui.location;

import gui.ui.component.CJLocation;
import gui.ui.component.CJPanel;

import javax.swing.border.TitledBorder;
import java.awt.*;

import static gui.ui.constants.DimensionConstants.*;
import static gui.ui.constants.GuiConstants.*;


public class LocationBarUI extends CJPanel {
    private CJLocation onDemandLocation;
    private CJLocation successLocation;
    private CJLocation failureLocation;
    private CJLocation logLocation;

    public LocationBarUI(CJPanel parent){

        onDemandLocation = new CJLocation(parent,"On Demand Dir", LOCATION_UI_TXT_FIELD_WIDTH);
        successLocation = new CJLocation(parent,"Success Dir",LOCATION_UI_TXT_FIELD_WIDTH);
        failureLocation = new CJLocation(parent,"Failure Dir",LOCATION_UI_TXT_FIELD_WIDTH);
        logLocation = new CJLocation(parent,"Log Dir",LOCATION_UI_TXT_FIELD_WIDTH);
        this.setLayout(new GridLayout(2,2, 0,0));
        this.add(onDemandLocation);
        this.add(successLocation);
        this.add(failureLocation);
        this.add(logLocation);
        this.setBorder(new TitledBorder(LINE_LGRAY_1THK_BORDER, "Job Specific Directories", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, TITLE_HEADER_1_FONT));
    }

    public CJLocation getOnDemandLocationUI() {
        return onDemandLocation;
    }

    public CJLocation getSuccessLocationUI() {
        return successLocation;
    }

    public CJLocation getFailureLocationUI() {
        return failureLocation;
    }

    public CJLocation getLogLocationUI() {
        return logLocation;
    }
}
