package gui.ui.screens;

public interface Screen {

    public void createUI();

    public void loadSettings();
}
