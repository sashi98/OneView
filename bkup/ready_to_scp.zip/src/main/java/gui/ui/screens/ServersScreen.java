package gui.ui.screens;

import gui.bean.ServerContext;
import gui.ui.RegisterListener;
import gui.ui.component.*;
import gui.ui.component.CJLocation;
import gui.ui.tables.server.ServersTableUI;
import gui.util.FileUtil;

import javax.swing.*;
import java.awt.*;

import static gui.ui.constants.DimensionConstants.*;
import static gui.ui.constants.IconConstants.*;
import static gui.util.GuiUtil.newDummyPanelObj;
import static java.awt.Image.SCALE_SMOOTH;

public class ServersScreen extends CJPanel implements Screen,RegisterListener {
    public static final String SERVER_NAME = "SERVER_NAME";
    public static final String SERVER_HOME = "SERVER_HOME";


    private ServersTableUI serversTableUI;
    private ServerContext serverContext;

    public ServersScreen(){
        this(new ServerContext());
    }
    public ServersScreen(ServerContext serverContext) {
        this.serverContext = serverContext;
        this.setFont(new Font("Arial", Font.PLAIN, 13));
        serversTableUI = new ServersTableUI(MAIN_GUI_WIDTH,SERVER_CENTER_PANEL_HEIGHT);
        createUI();
        registerListener();
        loadSettings();
    }

    @Override
    public void registerListener() {
        serversTableUI.getAddServerButton().addActionListener(e -> {
            CJTextField serverName = new CJTextField(250, TEXT_FIELD_HEIGHT);
            CJLocation serverLocation = new CJLocation(null, 280);
            Icon applyBtn = FileUtil.getScaledIcon(APPLY_ICON, ICON_WIDTH/2, ICON_HEIGHT/2, SCALE_SMOOTH);
            Icon cancelBtn = FileUtil.getScaledIcon(CANCEL_ICON, ICON_WIDTH/2, ICON_HEIGHT/2,SCALE_SMOOTH);
            Object[] options = {applyBtn, cancelBtn};

            final JComponent[] inputs = new JComponent[] {
                    new CJPanel(new CJLabel("Server Name"),serverName),
                    newDummyPanelObj(),
                    new CJPanel(new CJLabel("Server Path"),serverLocation)
            };
            int optionBtnClicked = JOptionPane.showOptionDialog(null, inputs,
                    "New User Variable", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
                    null, options, ""
                    );
            if (JOptionPane.YES_OPTION == optionBtnClicked){

                serverContext.set(SERVER_NAME, serverName.getText());
                serverContext.set(SERVER_HOME, serverLocation.getLocationTF().getText());
                serversTableUI.getServerTable().updateTable(serverContext);
            }
        });
    }

    @Override
    public void createUI() {
        this.setLayout(new BorderLayout(0, 0));
        this.add(serversTableUI,BorderLayout.CENTER);
    }

    @Override
    public void loadSettings() {

    }


//    @Override
//    public void registerListener() {
//        trashButton.addActionListener(actionEvent -> {
//            getTriggerLogTable().clearTable();
//        });
//    }
}
