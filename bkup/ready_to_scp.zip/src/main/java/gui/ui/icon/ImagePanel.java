package gui.ui.icon;

import gui.ui.RegisterListener;
import gui.ui.component.CJPanel;
import gui.util.ResourceLoader;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import static gui.util.GuiUtil.newDimentionObj;
import static java.awt.Image.SCALE_DEFAULT;
import static java.awt.Image.SCALE_SMOOTH;

public class ImagePanel extends CJPanel {
    Image image;
    ImageIcon imageIcon;

    public ImagePanel() {
        super();
    }

    public ImagePanel(String icon, int w, int h, boolean scaleNeeded, Color bg) {
        super();
        if (bg != null){
            setBackground(bg);
        }
        image = Toolkit.getDefaultToolkit().createImage(ResourceLoader.getResource(icon).getPath());
        imageIcon = new ImageIcon(image);
        if (scaleNeeded) {
            imageIcon.setImage(imageIcon.getImage().getScaledInstance(w, h, SCALE_SMOOTH));
        }
        setPreferredSize(newDimentionObj(w,h));
    }

    public ImagePanel(String icon) {
        setBackground(Color.WHITE);
        image = Toolkit.getDefaultToolkit().createImage(ResourceLoader.getResource(icon));
        imageIcon = new ImageIcon(image);

        setPreferredSize(newDimentionObj(imageIcon.getIconWidth(), imageIcon.getIconHeight()));
    }

    public ImagePanel(String icon, String toolTipText) {
        this(icon);
        setToolTipText(toolTipText);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (image != null) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.drawImage(imageIcon.getImage(), getWidth()/2-imageIcon.getIconWidth()/2, getHeight()/2-imageIcon.getIconHeight()/2, this);
        }
    }
}