package gui.ui;

public interface ContextListener {
    public void contextUpdate();
}
