package gui.ui;

import javax.swing.*;

public class ModelProvider {

    public static DefaultListModel<String> getListModel() {
        DefaultListModel<String> listModel = new DefaultListModel<>();
        listModel.addElement("My Elastic Search");
        listModel.addElement("Servers");
        listModel.addElement("Environment Variables");
        return listModel;
    }
}
