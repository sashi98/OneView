package gui.ui;

public interface RegisterListener {
    void registerListener();
}
