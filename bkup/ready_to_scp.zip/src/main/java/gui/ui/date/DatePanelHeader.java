package gui.ui.date;

import gui.ui.component.CJLabel;
import gui.ui.component.CJPanel;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;

import static gui.util.GuiUtil.*;

public class DatePanelHeader extends CJPanel {
    private JLabel hhTextLabel;
    private JLabel mmTextLabel;
    private JLabel ssTextLabel;

    public DatePanelHeader(int width, int height) {
        super(width,height);
        hhTextLabel = new CJLabel("HH");
        mmTextLabel = new CJLabel("MM");
        ssTextLabel = new CJLabel("SS");
        LayoutManager lm = new FlowLayout(FlowLayout.LEFT);
        this.setLayout(lm);
        this.add(newDummyPanelObj(208,1));
        this.add(hhTextLabel);
        this.add(newDummyPanelObj(5, 1));
        this.add(mmTextLabel);
        this.add(newDummyPanelObj(5, 1));
        this.add(ssTextLabel);
    }

}
