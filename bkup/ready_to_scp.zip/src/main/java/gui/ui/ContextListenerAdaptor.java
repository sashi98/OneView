package gui.ui;

public class ContextListenerAdaptor implements ContextListener {
    public void contextUpdate(){}
}
