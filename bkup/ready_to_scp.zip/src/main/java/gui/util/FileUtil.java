package gui.util;


import gui.bean.ESContext;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.util.List;

import static gui.bean.ESContext.*;
import static gui.ui.constants.TriggerFileConstants.*;


public class FileUtil {

    public static void onDemandTriggering(ESContext esContext) throws Exception {
        final String CRON_NAME = esContext.getStringValue(CRON_JOB_NAME);
        final String CRON_START_TAG = "<" + CRON_NAME + ">";
        final String CRON_END_TAG = "</" + CRON_NAME + ">";
        String input =
                XML_SPECIFICATION + NEW_LINE +
                        CRON_START_TAG + NEW_LINE +
                        TAB_SPACE + START_TIME_START_TAG + esContext.getStringValue(START_DATE_TIME) + START_TIME_END_TAG + NEW_LINE +
                        TAB_SPACE + END_TIME_START_TAG + esContext.getStringValue(END_DATE_TIME) + END_TIME_END_TAG + NEW_LINE +
                        CRON_END_TAG + NEW_LINE;

        try {
            File triggerFile = new File(esContext.getStringValue(ON_DEMAND_DIR_LOCATION), esContext.getStringValue(TRIGGER_FILE_NAME));
            Files.write(triggerFile.toPath(), input.getBytes());
        } catch (IOException e) {
            throw new Exception(e);
        }
    }

    public static ImageIcon getScaledIcon(ImageIcon icon, int w, int h, int scaleSmooth) {
        return new ImageIcon(icon.getImage().getScaledInstance(w, h, scaleSmooth));
    }

    public static ImageIcon getScaledIcon(String name, int w, int h, int scaleSmooth) {
        URL iconFile = ResourceLoader.getResource(name);
        try {
            Image img = ImageIO.read(iconFile).getScaledInstance(w, h, scaleSmooth);
            return new ImageIcon(img);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ImageIcon getIcon(String name) {
        URL iconFile = ResourceLoader.getResource(name);
        try {
            return new ImageIcon(ImageIO.read(iconFile));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getMatchedFile(String dir, String name) {
        File[] list = new File(dir).listFiles(pathname -> {
            return pathname.getName().contains(name.substring(0, (name.length() - ".XML".length())));
        });
        return list.length == 0 ? "" : list[0].getName();
    }

    public static void saveSettings(String filePath, List<ESContext> ESContextList) throws IOException {
        FileOutputStream fileOut = new FileOutputStream(filePath);
        ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
        objectOut.writeObject(ESContextList);
        objectOut.close();
    }

    public static List<ESContext> loadSettings(String filePath) throws IOException, ClassNotFoundException {
        FileInputStream is = new FileInputStream(filePath);
        ObjectInputStream ois = new ObjectInputStream(is);
        List<ESContext> mdList = (List<ESContext>) ois.readObject();
        ois.close();
        is.close();
        return mdList;
    }

    public static String readFile(String dir, String fileName) {
        try {
            return new String(Files.readAllBytes(new File(dir, fileName).toPath()));
        } catch (IOException e) {
            return "Error:"+e.getMessage();
        }

    }


}
