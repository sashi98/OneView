package gui.util;

import java.util.HashMap;
import java.util.Map;

public class EnvironmentVariables {
    public static Map<String, String> envVars = System.getenv();

    public static void add(String name, String val){
        if (envVars == null){
            envVars = new HashMap<>();
        }
        envVars.put(name, val);
    }
}
