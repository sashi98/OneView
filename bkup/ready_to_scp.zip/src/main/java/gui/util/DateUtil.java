package gui.util;

import org.apache.commons.lang3.time.DateFormatUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import static gui.util.DatePatterns.DF_YYYY_MM_DD_HH_MM_SS;

public class DateUtil {

    public static String getCurrentDateTime() {
        SimpleDateFormat sfd = new SimpleDateFormat(DF_YYYY_MM_DD_HH_MM_SS);
        String datetime = sfd.format(Calendar.getInstance().getTime());
        return datetime;
    }

    public static void sleep(int time){
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static Calendar getCurrentDateCalendarObj() {
        Calendar cal = Calendar.getInstance();
        return cal;
    }

    public static String getCurrentDateCalendarObj(String format) {
        return DateFormatUtils.format(getCurrentDateCalendarObj().getTime(), format);
    }

    public static String format(Calendar cal, String format) {
        return DateFormatUtils.format(cal.getTime(), format);
    }
}
