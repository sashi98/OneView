package gui.util;

import java.io.File;
import java.net.URL;
import java.nio.file.Path;
import java.util.Map;

public class ResourceLoader {

    private ResourceLoader(){
    }

    public static URL getResource(String resource){
        return ResourceLoader.class.getClass().getResource(resource);
    }


}
