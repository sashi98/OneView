package gui.util;

import org.apache.commons.lang3.StringUtils;

public class StringUtil {

    public static boolean isBlank(String string) {
        return StringUtils.isBlank(string) || string.equals("null") ? true : false;
    }

    public static boolean isNotBlank(String string) {
        return !isBlank(string);
    }

}
