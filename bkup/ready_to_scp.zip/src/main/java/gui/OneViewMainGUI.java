package gui;

import gui.bean.ESContext;
import gui.bean.ServerContext;
import gui.ui.screens.MyElasticSearchScreen;
import gui.ui.RegisterListener;

import gui.ui.component.CJPanel;
import gui.ui.component.list.CJList;
import gui.ui.component.tabbedpane.CJTabbedPane;
import gui.ui.component.tabbedpane.CJTabbedPaneUI;
import gui.ui.screens.ServersScreen;
import gui.util.FileUtil;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static gui.ui.ModelProvider.getListModel;
import static gui.ui.constants.DimensionConstants.*;

public class OneViewMainGUI extends JFrame implements RegisterListener {

    private List<ESContext> esContextList;
    private CJTabbedPane myESTabbedPane;
    private ServersScreen servers;
    private CJList list;
    private CJPanel mainPanel;

    OneViewMainGUI() {
        super("Deployment Util GUI");
        this.esContextList = new ArrayList<>();
        this.setLayout(new GridLayout(1,1));
    }

    public static void main(String[] args) {
        OneViewMainGUI mainGUI = new OneViewMainGUI();
        mainGUI.createWindow();
        mainGUI.packAndShow();
        mainGUI.registerListener();
       // mainGUI.loadMyESTabs();
    }

    private void packAndShow() {
        this.setPreferredSize(new Dimension(MAIN_GUI_WIDTH, MAIN_GUI_HEIGHT));
        this.setResizable(false);
        this.setVisible(true);
        this.setLocation(WINDOW_X, WINDOW_Y);
        this.pack();
    }

    private void createWindow() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.createUI();
    }

    private void createUI() {
        this.mainPanel = new CJPanel(new LineBorder(Color.black));
        this.mainPanel.setLayout(new BorderLayout(0,0));
        this.myESTabbedPane = new CJTabbedPane(new CJTabbedPaneUI(CJTabbedPaneUI.ICON_ALIGN.RIGHT));
        this.list = new CJList(getListModel());
        {
            CJPanel panel = new CJPanel(list, true, Color.RED, Color.GREEN);
            panel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.WHITE, Color.GRAY));
            this.mainPanel.add(panel, BorderLayout.WEST);
            {//Default View
                this.list.setSelectedIndex(0);
                mainPanel.add(myESTabbedPane, BorderLayout.CENTER);
            }
        }
        this.servers = new ServersScreen(new ServerContext());
        this.add(this.mainPanel);
    }


    private void loadMyESTabs() {
        try {
            esContextList = FileUtil.loadSettings("./master_data.cache");
        } catch (Exception ex) {
            esContextList = new ArrayList<>();
            ex.printStackTrace();
        }
        esContextList.forEach(esContext -> loadMyESTab(esContext));
        if (esContextList.isEmpty()) {
            loadMyESTab(null);
        }
    }

    private void loadMyESTab(ESContext esContext) {
        if (esContext == null) {
            esContext = new ESContext();
            esContext.set(ESContext.TITLE, "MyES");
            esContextList.add(esContext);
        }
        MyElasticSearchScreen myES = new MyElasticSearchScreen(esContext);
        myESTabbedPane.add(esContext.getStringValue(ESContext.TITLE), myES);
    }

    private void registerWindowListener() {
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                loadMyESTabs();
            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    updateContext();
                    FileUtil.saveSettings("./master_data.cache", esContextList);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    private void updateContext() {
        esContextList = new ArrayList<>();
        for (int t = 0; t < myESTabbedPane.getTabCount() - 1; t++) {
            esContextList.add(((MyElasticSearchScreen) myESTabbedPane.getComponentAt(t)).getEsContext());
        }
    }

    @Override
    public void registerListener() {
        registerWindowListener();
        registerListSelectionListener();

    }

    private void registerListSelectionListener() {

        list.addListSelectionListener(e -> {
            if (list.getSelectedValue().equals(getListModel().elementAt(0))){
                this.mainPanel.remove(servers);
                mainPanel.add(myESTabbedPane, BorderLayout.CENTER);
            }
            if (list.getSelectedValue().equals(getListModel().elementAt(1))){
                this.mainPanel.remove(myESTabbedPane);
                this.mainPanel.add(servers, BorderLayout.CENTER);
            }
            this.mainPanel.revalidate();
            this.mainPanel.validate();
            this.mainPanel.repaint();
            setVisible(true);
        });
    }
}
