package gui;

public interface TableData {
}
