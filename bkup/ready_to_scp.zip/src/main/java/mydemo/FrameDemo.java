package mydemo;

import gui.ui.component.CJButton;
import gui.ui.component.CJPanel;
import gui.util.FileUtil;

import javax.swing.*;
import java.awt.*;

import static gui.ui.constants.DimensionConstants.ICON_HEIGHT;
import static gui.ui.constants.DimensionConstants.ICON_WIDTH;
import static gui.ui.constants.IconConstants.*;

public class FrameDemo extends JFrame  {
    private final static int WIDTH = 700;
    private final static int HEIGHT = 500;
    FrameDemo() {
        super("Deployment Util GUI");
    }

    public static void main(String[] args) {
        FrameDemo mainGUI = new FrameDemo();
        createWindow(mainGUI);
    }

    private static void createWindow(FrameDemo mainGUI) {
        mainGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainGUI.createUI();
    }

    private void createUI(){
       // CJButton button = new CJButton(FileUtil.getIcon(ICON_GIF_DIR+ SLASH +"busy_spin.gif"),ICON_WIDTH, ICON_HEIGHT,"Hi");
       // CJButton button = new CJButton("");
        this.add(new CJPanel(BUSY_SPIN_IP));
        this.setSize(new Dimension(WIDTH, HEIGHT));
        this.setVisible(true);
    }
}
