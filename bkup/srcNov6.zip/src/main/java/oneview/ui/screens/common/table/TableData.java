package oneview.ui.screens.common.table;

public interface TableData {
}
