package oneview.ui.screens.common.util;

import oneview.bean.PomInfo;
import oneview.ui.component.CJLabel;
import oneview.ui.component.CJPanel;
import oneview.ui.component.CJTextField;
import oneview.ui.screens.build.BuildScreen;
import oneview.ui.screens.build.context.BuildContext;
import oneview.ui.screens.build.AddRemoveBuildCommandUI;
import oneview.ui.screens.build.table.BuildTableData;
import oneview.util.FileUtil;

import javax.swing.*;
import java.awt.*;

import static oneview.ui.constants.DimensionConstants.*;
import static oneview.ui.constants.IconConstants.APPLY_ICON;
import static oneview.ui.constants.IconConstants.CANCEL_ICON;
import static oneview.ui.screens.build.BuildScreen.BUILDS;
import static oneview.ui.screens.build.BuildScreen.NEW_BUILD_ADDED;
import static oneview.util.GuiUtil.newDummyPanelObj;
import static java.awt.Image.SCALE_SMOOTH;

public class ScreenUtil {

    public static int showEditBuildUI(String title, BuildContext buildContext, BuildTableData data, BuildScreen screen) {
        CJTextField projectNameTF = new CJTextField(360, TEXT_FIELD_HEIGHT);
        projectNameTF.setText(data == null ? "" : data.getProject());

        AddRemoveBuildCommandUI addRemoveBuildCommandUI = new AddRemoveBuildCommandUI(data);
        Icon applyBtn = FileUtil.getScaledIcon(APPLY_ICON, ICON_WIDTH / 2, ICON_HEIGHT / 2, SCALE_SMOOTH);
        Icon cancelBtn = FileUtil.getScaledIcon(CANCEL_ICON, ICON_WIDTH / 2, ICON_HEIGHT / 2, SCALE_SMOOTH);
        Object[] options = {applyBtn, cancelBtn};

        final JComponent[] inputs = new JComponent[]{
                new CJPanel(new CJLabel("Project Name"), projectNameTF, new FlowLayout(FlowLayout.LEFT)),
                newDummyPanelObj(),
                addRemoveBuildCommandUI
        };
        int optionBtnClicked = JOptionPane.showOptionDialog(screen, inputs,
                title, JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, ""
        );

        if (JOptionPane.YES_OPTION == optionBtnClicked) {
            String projectName = projectNameTF.getText();
            java.util.List<PomInfo> commands = addRemoveBuildCommandUI.getBuildCommandList();
            if (data == null) {
                data = new BuildTableData();
            }
            data.setProject(projectName);
            data.setCommands(commands);
            buildContext.remove(NEW_BUILD_ADDED);
            buildContext.set(NEW_BUILD_ADDED, data);

            buildContext.getListValue(BUILDS).remove(data);
            buildContext.getListValue(BUILDS).add(data);

            buildContext.set(BUILDS, buildContext.getListValue(BUILDS));
        }
        return optionBtnClicked;
    }
}
