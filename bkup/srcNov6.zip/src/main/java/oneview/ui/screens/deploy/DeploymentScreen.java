package oneview.ui.screens.deploy;

import oneview.ui.RegisterListener;
import oneview.ui.component.CJLocation;
import oneview.ui.component.CJPanel;
import oneview.ui.component.CJTextField;
import oneview.ui.screens.common.IScreen;
import oneview.ui.screens.deploy.context.DeploymentContext;
import oneview.ui.screens.deploy.table.DeployTableUI;
import oneview.util.FileUtil;

import javax.swing.*;
import java.awt.*;

import static java.awt.Image.SCALE_SMOOTH;
import static oneview.ui.constants.DimensionConstants.*;
import static oneview.ui.constants.IconConstants.APPLY_ICON;
import static oneview.ui.constants.IconConstants.CANCEL_ICON;
import static oneview.util.GuiUtil.newDummyPanelObj;

public class DeploymentScreen extends CJPanel implements IScreen, RegisterListener {
   

    public static final String NEW_SERVER_ADDED = "NEW_SERVER_ADDED";
    
    private DeployTableUI deployTableUI;
    private DeploymentContext serverContext;

    public DeploymentScreen(){
        this(new DeploymentContext());
    }
    public DeploymentScreen(DeploymentContext serverContext) {
        this.serverContext = serverContext;
        this.setFont(new Font("Arial", Font.PLAIN, 13));
        deployTableUI = new DeployTableUI(MAIN_GUI_WIDTH,SERVER_CENTER_PANEL_HEIGHT);
        createUI();
        registerListener();
        loadSettings();
    }

    @Override
    public void registerListener() {
        DeploymentScreen deployScreen = this;
        deployTableUI.getAddDeployButton().addActionListener(e -> {
//            CJTextField serverName = new CJTextField(250, TEXT_FIELD_HEIGHT);
//            CJLocation serverHomeLocation = new CJLocation(null, 280, JFileChooser.FILES_AND_DIRECTORIES);
//            CJLocation serverStartLocation = new CJLocation(null, 280, JFileChooser.FILES_AND_DIRECTORIES);
//            CJLocation serverStopLocation = new CJLocation(null, 280, JFileChooser.FILES_AND_DIRECTORIES);
//            Icon applyBtn = FileUtil.getScaledIcon(APPLY_ICON, ICON_WIDTH/2, ICON_HEIGHT/2, SCALE_SMOOTH);
//            Icon cancelBtn = FileUtil.getScaledIcon(CANCEL_ICON, ICON_WIDTH/2, ICON_HEIGHT/2,SCALE_SMOOTH);
//            Object[] options = {applyBtn, cancelBtn};
//
//            serverName.setText("Weblogic");
//            serverHomeLocation.getLocationTF().setText("/opt/oracle/weblogic12cR2/user_projects/domains/healthedge");
//            serverStartLocation.getLocationTF().setText("/opt/oracle/weblogic12cR2/user_projects/domains/healthedge/start_server.sh");
//            serverStopLocation.getLocationTF().setText("/opt/oracle/weblogic12cR2/user_projects/domains/healthedge/stop_server.sh");
//            final JComponent[] inputs = new JComponent[] {
//                    new CJPanel(new CJLabel("Deploy Name"),serverName),
//                    newDummyPanelObj(),
//                    new CJPanel(new CJLabel("Deploy Home"),serverHomeLocation),
//                    newDummyPanelObj(),
//                    new CJPanel(new CJLabel("Deploy Start"),serverStartLocation),
//                    newDummyPanelObj(),
//                    new CJPanel(new CJLabel("Deploy Stop"),serverStopLocation)
//            };
//            int optionBtnClicked = JOptionPane.showOptionDialog(null, inputs,
//                    "New Deploy", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
//                    null, options, ""
//                    );
//            if (JOptionPane.YES_OPTION == optionBtnClicked){
//                DeployTableData newDeploy = new DeployTableData();
//                newDeploy.setDeployName(serverName.getText());
//                newDeploy.setDeployHome(serverHomeLocation.getLocationTF().getText());
//                newDeploy.setStartScriptPath(serverStartLocation.getLocationTF().getText());
//                newDeploy.setStopScriptPath(serverStopLocation.getLocationTF().getText());
//                serverContext.set(NEW_SERVER_ADDED, newDeploy);
//                deployTableUI.getDeployTable().updateTable(serverContext);
           // }
        });
    }

    @Override
    public void createUI() {
        this.setLayout(new BorderLayout(0, 0));
        this.add(deployTableUI,BorderLayout.CENTER);
    }

    @Override
    public void loadSettings() {

    }


//    @Override
//    public void registerListener() {
//        trashButton.addActionListener(actionEvent -> {
//            getTriggerLogTable().clearTable();
//        });
//    }
}
