package oneview.ui.screens.deploy.table;

import oneview.ui.screens.common.table.TableData;

import java.util.Date;

import static oneview.ui.constants.GuiConstants.*;


public class DeployTableData implements TableData {
    private String featureName;
    private Date deploymentTime;
    private String installOrUninstall;
    private String reinstall;
    private String log;
    private String viewPipeline;

    public DeployTableData() {
        featureName = "ucare";
        deploymentTime = new Date();
        installOrUninstall= FEATURE_UNINSTALLED;
        reinstall = FEATURE_REINSTALL;
        log = RUN_LOG;
        viewPipeline=VIEW_PIPELINE_STATE;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public Date getDeploymentTime() {
        return deploymentTime;
    }

    public void setDeploymentTime(Date deploymentTime) {
        this.deploymentTime = deploymentTime;
    }

    public String getInstallOrUninstall() {
        return installOrUninstall;
    }

    public void setInstallOrUninstall(String installOrUninstall) {
        this.installOrUninstall = installOrUninstall;
    }

    public String getReinstall() {
        return reinstall;
    }

    public void setReinstall(String reinstall) {
        this.reinstall = reinstall;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public String getViewPipeline() {
        return viewPipeline;
    }

    public void setViewPipeline(String viewPipeline) {
        this.viewPipeline = viewPipeline;
    }
}
