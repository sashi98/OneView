package oneview.ui.screens.deploy.pipeline;

import oneview.ui.component.CJPanel;
import oneview.ui.screens.deploy.pipeline.table.PipelineTable;
import oneview.ui.screens.deploy.pipeline.table.PipelineTableDataModel;

import javax.swing.*;
import java.awt.*;

public class PipelineUI extends CJPanel {
    private PipelineTable table;
    private PipelineTableDataModel model;

    public PipelineUI(int w, int h) {
        super(w,h);
        this.setLayout(new GridLayout(1,1,0,0));
        model = new PipelineTableDataModel();
        table = new PipelineTable(model);
        JScrollPane tableScrollPane = new JScrollPane(table);
        tableScrollPane.setLayout(new ScrollPaneLayout());
        this.add(tableScrollPane);
    }
}
