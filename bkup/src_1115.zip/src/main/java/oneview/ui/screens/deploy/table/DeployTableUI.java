package oneview.ui.screens.deploy.table;

import oneview.ui.RegisterListener;
import oneview.ui.component.CJButton;
import oneview.ui.component.CJPanel;
import oneview.ui.screens.deploy.table.DeployTable;
import oneview.ui.screens.deploy.table.DeployTableDataModel;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.ArrayList;

import static oneview.ui.constants.DimensionConstants.ICON_HEIGHT;
import static oneview.ui.constants.DimensionConstants.ICON_WIDTH;
import static oneview.ui.constants.GuiConstants.LINE_LGRAY_1THK_BORDER;
import static oneview.ui.constants.GuiConstants.TITLE_HEADER_1_FONT;
import static oneview.ui.constants.IconConstants.ADD_DEFAULT_ICON;
import static oneview.ui.constants.IconConstants.ADD_HOVERED_ICON;

public class DeployTableUI extends CJPanel implements RegisterListener {
    private DeployTable deployTable;
    private CJButton addDeployButton;

    public DeployTableUI(int width, int height) {
        super(width,height);
        deployTable = new DeployTable(new DeployTableDataModel(new ArrayList<>()));
        addDeployButton = new CJButton(ADD_DEFAULT_ICON, ADD_HOVERED_ICON, ICON_WIDTH, ICON_HEIGHT, "Add Deploy");
        JScrollPane tableScrollPane = new JScrollPane(deployTable);
        tableScrollPane.setLayout(new ScrollPaneLayout());
        this.setLayout(new BorderLayout(0,0));
        CJPanel panel = new CJPanel(width, ICON_HEIGHT);
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT, 0,0));
        panel.add(addDeployButton);
        //panel.add(trashButton);
        this.add(panel, BorderLayout.NORTH);
        this.add(tableScrollPane, BorderLayout.CENTER);
        this.setBorder(new TitledBorder(LINE_LGRAY_1THK_BORDER, "Deploys", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, TITLE_HEADER_1_FONT));
        registerListener();
    }

    public DeployTable getDeployTable() {
        return deployTable;
    }

    public void setDeployTable(DeployTable deployTable) {
        this.deployTable = deployTable;
    }

    public CJButton getAddDeployButton() {
        return addDeployButton;
    }

    public void setAddDeployButton(CJButton addDeployButton) {
        this.addDeployButton = addDeployButton;
    }

    @Override
    public void registerListener() {

    }


//    @Override
//    public void registerListener() {
//        trashButton.addActionListener(actionEvent -> {
//            getTriggerLogTable().clearTable();
//        });
//    }
}
