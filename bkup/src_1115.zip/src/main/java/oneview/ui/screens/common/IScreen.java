package oneview.ui.screens.common;

public interface IScreen {

    public void createUI();

    public void loadSettings();
}
