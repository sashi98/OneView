package oneview.ui;

public interface ContextListener {
    public void contextUpdate();
}
