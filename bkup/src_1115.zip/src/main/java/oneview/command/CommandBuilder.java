package oneview.command;

public interface CommandBuilder {
    public void construct();
}
