package oneview.util;

import org.apache.commons.lang3.StringUtils;

import java.io.File;

public class StringUtil {

    private StringUtil(){}

    public static boolean isBlank(String string) {
        return StringUtils.isBlank(string) || string.equals("null");
    }

    public static boolean isNotBlank(String string) {
        return !isBlank(string);
    }


    public static String getArtifactID(File pomFile) {
        File dir = pomFile.getParentFile();
        return dir.getName();
    }


}
