package oneview.ui.screens.common.util;

import oneview.bean.PomInfo;
import oneview.ui.component.*;
import oneview.ui.screens.build.BuildScreen;
import oneview.ui.screens.build.context.BuildContext;
import oneview.ui.screens.build.AddRemoveBuildCommandUI;
import oneview.ui.screens.build.table.BuildTableData;
import oneview.ui.screens.deploy.ArtifactUI;
import oneview.ui.screens.deploy.DeploymentScreen;
import oneview.ui.screens.deploy.context.DeploymentContext;
import oneview.ui.screens.deploy.table.DeployTableData;
import oneview.ui.screens.deploy.table.DeployTableUI;
import oneview.util.DateUtil;
import oneview.util.FileUtil;

import javax.swing.*;
import java.awt.*;

import static oneview.ui.constants.DimensionConstants.*;
import static oneview.ui.constants.GuiConstants.FEATURE_REINSTALL;
import static oneview.ui.constants.GuiConstants.FEATURE_UNINSTALLED;
import static oneview.ui.constants.IconConstants.*;
import static oneview.ui.screens.build.BuildScreen.BUILDS;
import static oneview.ui.screens.build.BuildScreen.NEW_BUILD_ADDED;
import static oneview.ui.screens.deploy.DeploymentScreen.ARTIFACTS;
import static oneview.ui.screens.deploy.DeploymentScreen.NEW_ARTIFACT_ADDED;
import static oneview.util.DatePatterns.DP_YYYY_MM_DD_HH_MM_SS;
import static oneview.util.GuiUtil.newDummyPanelObj;
import static java.awt.Image.SCALE_SMOOTH;

public class ScreenUtil {

    public static int showEditBuildUI(String title, BuildContext context, BuildTableData data, BuildScreen screen) {
        CJTextField projectNameTF = new CJTextField(360, TEXT_FIELD_HEIGHT);
        projectNameTF.setText(data == null ? "" : data.getProject());

        AddRemoveBuildCommandUI addRemoveBuildCommandUI = new AddRemoveBuildCommandUI(data);
        Icon applyBtn = FileUtil.getScaledIcon(APPLY_ICON, ICON_WIDTH / 2, ICON_HEIGHT / 2, SCALE_SMOOTH);
        Icon cancelBtn = FileUtil.getScaledIcon(CANCEL_ICON, ICON_WIDTH / 2, ICON_HEIGHT / 2, SCALE_SMOOTH);
        Object[] options = {applyBtn, cancelBtn};

        final JComponent[] inputs = new JComponent[]{
                new CJPanel(new CJLabel("Project Name"), projectNameTF, new FlowLayout(FlowLayout.LEFT)),
                newDummyPanelObj(),
                addRemoveBuildCommandUI
        };
        int optionBtnClicked = JOptionPane.showOptionDialog(screen, inputs,
                title, JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, ""
        );

        if (JOptionPane.YES_OPTION == optionBtnClicked) {
            String projectName = projectNameTF.getText();
            java.util.List<PomInfo> commands = addRemoveBuildCommandUI.getBuildCommandList();
            if (data == null) {
                data = new BuildTableData();
            }
            data.setProject(projectName);
            data.setCommands(commands);
            context.remove(NEW_BUILD_ADDED);
            context.set(NEW_BUILD_ADDED, data);

            context.getListValue(BUILDS).remove(data);
            context.getListValue(BUILDS).add(data);

            context.set(BUILDS, context.getListValue(BUILDS));
        }
        return optionBtnClicked;
    }

    public static int showAddArtifactDialog(String title, DeploymentContext context, DeployTableUI screen) {
        ArtifactUI artifactUI = new ArtifactUI();
        Icon applyBtn = FileUtil.getScaledIcon(APPLY_ICON, ICON_WIDTH / 2, ICON_HEIGHT / 2, SCALE_SMOOTH);
        Icon cancelBtn = FileUtil.getScaledIcon(CANCEL_ICON, ICON_WIDTH / 2, ICON_HEIGHT / 2, SCALE_SMOOTH);
        Object[] options = {applyBtn, cancelBtn};

        final JComponent[] inputs = new JComponent[]{
                artifactUI
        };
        int optionBtnClicked = JOptionPane.showOptionDialog(screen, inputs,
                title, JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, ""
        );

        if (JOptionPane.YES_OPTION == optionBtnClicked) {
            DeployTableData data = new DeployTableData();
            data.setDeploymentTime(DateUtil.getCurrentDateObj(DP_YYYY_MM_DD_HH_MM_SS));
            data.setFeatureName(artifactUI.getArtifactPath().getName());
            data.setArtifactPath(artifactUI.getArtifactPath());
            data.setInstallOrUninstall(FEATURE_UNINSTALLED);
            data.setReinstall(FEATURE_REINSTALL);
            context.set(NEW_ARTIFACT_ADDED, data);
            context.getListValue(ARTIFACTS).add(data);
        }
        return optionBtnClicked;
    }
}
