package oneview.ui.screens.deploy.table;

import oneview.bean.PomInfo;
import oneview.ui.screens.build.table.BuildTableData;
import oneview.ui.screens.common.table.TableData;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static oneview.ui.constants.GuiConstants.*;


public class DeployTableData implements TableData {
    private String featureName;
    private Date deploymentTime;
    private String installOrUninstall;
    private String reinstall;
    private String log;
    private String viewPipeline;
    private File artifactPath;

    public DeployTableData() {
        installOrUninstall= FEATURE_UNINSTALLED;
        reinstall = FEATURE_REINSTALL;
        viewPipeline=VIEW_PIPELINE_STATE;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public Date getDeploymentTime() {
        return deploymentTime;
    }

    public void setDeploymentTime(Date deploymentTime) {
        this.deploymentTime = deploymentTime;
    }

    public String getInstallOrUninstall() {
        return installOrUninstall;
    }

    public void setInstallOrUninstall(String installOrUninstall) {
        this.installOrUninstall = installOrUninstall;
    }

    public String getReinstall() {
        return reinstall;
    }

    public void setReinstall(String reinstall) {
        this.reinstall = reinstall;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public String getViewPipeline() {
        return viewPipeline;
    }

    public void setViewPipeline(String viewPipeline) {
        this.viewPipeline = viewPipeline;
    }

    public void setArtifactPath(File artifactPath) {
        this.artifactPath = artifactPath;
    }

    public File getArtifactPath() {
        return artifactPath;
    }

    @Override
    protected DeployTableData clone() {
        DeployTableData cloned = new DeployTableData();
        cloned.setReinstall(getReinstall());
        cloned.setInstallOrUninstall(getInstallOrUninstall());
        cloned.setFeatureName(getFeatureName());
        cloned.setDeploymentTime(getDeploymentTime());
        cloned.setLog(getLog());
        cloned.setViewPipeline(getViewPipeline());
        return cloned;
    }

}
