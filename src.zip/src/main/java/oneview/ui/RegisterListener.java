package oneview.ui;

public interface RegisterListener {
    void registerListener();
}
