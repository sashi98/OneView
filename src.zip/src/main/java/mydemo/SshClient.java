package mydemo;

import com.jcraft.jsch.*;

import java.io.IOException;
import java.io.InputStream;

import static oneview.util.ThreadUtil.sleep;

public class SshClient {
    public static void main(String[] args) {
        String host = "heeng-sprasad";
        String user = "connector";
        String password = "Connector123";
        String command = "list|grep ucare-medi";
        try {

            JSch jsch = new JSch();
            Session session = jsch.getSession(user,host, 8101);
            session.setUserInfo(new UserInfo() {
                @Override
                public String getPassphrase() {
                    throw new UnsupportedOperationException("getPassphrase Not supported yet.");
                }

                @Override
                public String getPassword() {
                    return password;
                }

                @Override
                public boolean promptPassword(String s) {
                    return true;
                }

                @Override
                public boolean promptPassphrase(String s) {
                    throw new UnsupportedOperationException("promptPassphrase Not supported yet.");
                }

                @Override
                public boolean promptYesNo(String s) {
                    return true;
                }

                @Override
                public void showMessage(String s) {

                }
            });
            session.connect();
            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand(command);
            //channel.setInputStream(new ByteArrayInputStream(command.getBytes(StandardCharsets.UTF_8)));
            channel.setOutputStream(System.out);
            InputStream in = channel.getInputStream();
            StringBuilder outBuff = new StringBuilder();
            int exitStatus = -1;

            channel.connect();
            sleep(5000);
            while (true) {
                for (int c; ((c = in.read()) >= 0);) {
                    outBuff.append((char) c);
                }

                if (channel.isClosed()) {
                    if (in.available() > 0) continue;
                    exitStatus = channel.getExitStatus();
                    break;
                }
            }
            channel.disconnect();
            session.disconnect();

            // print the buffer's contents
            System.out.print (outBuff.toString());
            // print exit status
            System.out.print ("Exit status of the execution: " + exitStatus);
            if ( exitStatus == 0 ) {
                System.out.print (" (OK)\n");
            } else {
                System.out.print (" (NOK)\n");
            }

        } catch (IOException | JSchException ioEx) {
            ioEx.printStackTrace();
        }
    }
}
